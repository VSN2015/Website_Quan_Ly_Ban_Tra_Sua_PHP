<?php
    session_start();
    //include('Library/database.php');

        if(isset($_GET['controller'])){
            switch($_GET['controller']){
                case "user":include('Controllers/User/controller.php');
                            break;
                case "admin":include('Controllers/Admin/controller.php');
                            break;
                case "home":include('Controllers/index.php');
                            break;
                
            }
        }
        else{
            header("location:index.php?controller=home");
        }
?>