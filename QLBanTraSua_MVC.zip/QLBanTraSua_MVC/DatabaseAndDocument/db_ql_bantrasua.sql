-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2019 at 01:29 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ql_bantrasua`
--

-- --------------------------------------------------------

--
-- Table structure for table `cthd`
--

CREATE TABLE `cthd` (
  `ID_CTHD` int(11) NOT NULL,
  `ID_HD` int(11) NOT NULL,
  `ID_SP` int(11) NOT NULL,
  `SoLuong` int(11) NOT NULL,
  `Size` char(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cthd`
--

INSERT INTO `cthd` (`ID_CTHD`, `ID_HD`, `ID_SP`, `SoLuong`, `Size`) VALUES
(1, 4, 10, 1, 'M'),
(2, 4, 6, 1, 'M'),
(3, 5, 10, 1, 'M'),
(4, 5, 6, 1, 'M'),
(5, 6, 2, 1, 'M'),
(6, 7, 10, 3, 'M'),
(7, 7, 10, 4, 'M'),
(8, 8, 18, 3, ''),
(9, 8, 16, 1, ''),
(10, 8, 22, 1, ''),
(11, 8, 23, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `donvitinh`
--

CREATE TABLE `donvitinh` (
  `ID_SP` int(11) NOT NULL,
  `Size` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `Gia` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `donvitinh`
--

INSERT INTO `donvitinh` (`ID_SP`, `Size`, `Gia`) VALUES
(1, 'L', 40000),
(1, 'M', 30000),
(2, 'L', 95000),
(2, 'M', 35000),
(3, 'L', 50000),
(3, 'M', 40000),
(4, 'L', 30000),
(4, 'M', 20000),
(5, 'L', 50000),
(5, 'M', 40000),
(6, 'L', 30000),
(6, 'M', 20000),
(7, 'L', 40000),
(7, 'M', 30000),
(8, 'L', 30000),
(8, 'M', 20000),
(9, 'L', 40000),
(9, 'M', 30000),
(10, 'L', 40000),
(10, 'M', 30000),
(11, 'L', 30000),
(11, 'M', 20000),
(12, 'L', 35000),
(12, 'M', 25000),
(13, 'L', 35000),
(13, 'M', 25000),
(14, '0', 30000),
(15, '0', 20000),
(16, '0', 20000),
(17, '0', 25000),
(18, '0', 18000),
(19, '0', 25000),
(20, '0', 30000),
(21, '0', 25000),
(22, '0', 25000),
(23, '0', 30000),
(24, '0', 110000),
(31, '0', 110000),
(35, '0', 20000);

-- --------------------------------------------------------

--
-- Table structure for table `hoadon`
--

CREATE TABLE `hoadon` (
  `ID_HD` int(11) NOT NULL,
  `ID_KH` int(11) NOT NULL,
  `NgayGio_HD` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `NgayGio_GiaoHang` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Tien_GiaoHang` int(11) NOT NULL DEFAULT '0',
  `TenKH_GiaoHang` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DiaChi_GiaoHang` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `SDT_GiaoHang` char(10) COLLATE utf8_unicode_ci NOT NULL,
  `Email_GiaoHang` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `TrangThaiGiaoHang` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `hoadon`
--

INSERT INTO `hoadon` (`ID_HD`, `ID_KH`, `NgayGio_HD`, `NgayGio_GiaoHang`, `Tien_GiaoHang`, `TenKH_GiaoHang`, `DiaChi_GiaoHang`, `SDT_GiaoHang`, `Email_GiaoHang`, `TrangThaiGiaoHang`) VALUES
(3, 14, '2019-05-20 02:24:56', '2019-05-20 02:24:56', 50000, 'Nguyễn Thị Như Thương', 'Quảng Nam', '0969068625', 'sangnguyen07dhth@gmail.com', 'Đến cửa hàng lấy hàng'),
(4, 14, '2019-05-20 02:25:25', '2019-05-20 02:25:25', 50000, 'Nguyễn Thị Như Thương', 'Quảng Nam', '0969068625', 'sangnguyen07dhth@gmail.com', 'Đến cửa hàng lấy hàng'),
(5, 14, '2019-05-20 02:26:50', '2019-05-20 02:26:50', 50000, 'Nguyễn Thị Như Thương', 'Quảng Nam', '0969068625', 'sangnguyen07dhth@gmail.com', 'Thanh toán khi giao hàng'),
(6, 14, '2019-05-20 02:27:52', '2019-05-20 02:27:52', 35000, 'Nguyễn Thị Như Thương', 'Quảng Nam', '0966856211', 'sangnguyen07dhth@gmail.com', 'Thanh toán khi giao hàng'),
(7, 14, '2019-05-20 03:13:20', '2019-05-20 03:13:20', 210000, 'Nguyễn Thị Như Thương', 'Tây Ninh', '0966856211', 'sangnguyen07dhth@gmail.com', 'Đến cửa hàng lấy hàng'),
(8, 14, '2019-05-20 23:10:21', '2019-05-20 23:10:21', 129000, 'Chinanana', 'Nghĩa Địa Bến Tre', '0964440775', 'nguyenkhang1400@gmail.com', 'Thanh toán khi giao hàng');

-- --------------------------------------------------------

--
-- Table structure for table `khachhang`
--

CREATE TABLE `khachhang` (
  `ID_KH` int(11) NOT NULL,
  `HoTenKH` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `DiaChiKH` varchar(150) COLLATE utf8_unicode_ci DEFAULT 'Chưa nhập địa chỉ',
  `SDT` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `EmailKH` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `khachhang`
--

INSERT INTO `khachhang` (`ID_KH`, `HoTenKH`, `DiaChiKH`, `SDT`, `EmailKH`) VALUES
(14, 'Nguyễn Văn Sang', 'Quảng Nam', '0966856211', 'sangnguyen07dhth@gmail.com'),
(19, 'chinanana', 'ca mau', '0964440776', 'nguyenkhang1400@gmail.com'),
(20, 'Nguyễn Văn Sang', 'sssssssssssssss', '0969068625', 'sangnguyen07dhth@istore.edu.vn');

-- --------------------------------------------------------

--
-- Table structure for table `nhanvien`
--

CREATE TABLE `nhanvien` (
  `ID_NV` int(11) NOT NULL,
  `HoTenNV` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `NgaySinh` date DEFAULT NULL,
  `DiaChiNV` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `AnhNV` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `QuyenTruyCap` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `LuongNV` int(11) NOT NULL,
  `GioiTinh` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `nhanvien`
--

INSERT INTO `nhanvien` (`ID_NV`, `HoTenNV`, `NgaySinh`, `DiaChiNV`, `AnhNV`, `QuyenTruyCap`, `Email`, `LuongNV`, `GioiTinh`) VALUES
(2, 'Nguyễn Văn Sang', NULL, NULL, '', 'Admin', 'sn5648562@gmail.com', 0, NULL),
(3, 'Nguyễn Như Thương', '0000-00-00', 'Tây Ninh', '18953116_666818723514595_4256331949705681754_n.jpg', 'Nhân Viên', 'nhu8103@gmail.com', 50000000, 'male');

-- --------------------------------------------------------

--
-- Table structure for table `sanpham`
--

CREATE TABLE `sanpham` (
  `ID_SP` int(11) NOT NULL,
  `TenSP` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `ID_TheLoaiSP` int(11) NOT NULL,
  `AnhSP` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `GiamGia` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sanpham`
--

INSERT INTO `sanpham` (`ID_SP`, `TenSP`, `ID_TheLoaiSP`, `AnhSP`, `GiamGia`) VALUES
(1, 'Hồng trà sữa tươi', 1, 'hongtrasuatuoi.jpg', 0),
(2, 'TS trân châu đá xay', 1, 'tranchaudaxay.jpg', 0),
(3, 'TS trân châu sữa tươi', 1, 'tranchausuatuoi.jpg', 0),
(4, 'Trà sữa khoai môn', 1, 'trasuakhoaimon.jpg', 0),
(5, 'Trà sữa mật ong', 1, 'trasuamatong.jpg', 0),
(6, 'Trà sữa trân châu', 1, 'trasuatranchau.jpg', 0),
(7, 'TS trân châu Hokkido', 1, 'trasuatranchauhokkido.jpg', 0),
(8, 'Trà sữa tươi', 1, 'trasuatuoi.jpg', 0),
(9, 'Trà sữa hoa lục trà', 1, 'tshoaluctra.jpg', 0),
(10, 'Trà sữa ô long', 1, 'tsolong.jpg', 0),
(11, 'Trà sữa trà xanh', 1, 'tstraxanh.jpg', 0),
(12, 'Trà sữa vãi', 1, 'tsvai.jpg', 0),
(13, 'Trà sữa xoài', 1, 'tsxoai.jpg', 0),
(14, 'Café Capochino', 2, 'cafe_capochino.jpg', 0),
(15, 'Café đen truyền thống', 2, 'cafe_dentruyenthong.jpg', 0),
(16, 'Café đen nóng', 2, 'cafe_dennong.jpg', 0),
(17, 'Café pha máy', 2, 'cafe_phamay.jpg', 0),
(18, 'Café sữa vị gừng', 2, 'cafe_sua_vigung.jpg', 0),
(19, 'Café sữa vị ngọt', 2, 'cafe_sua_vingot.jpg', 0),
(20, 'Café sữa kem', 2, 'cafe_suakem.jpg', 0),
(21, 'Café sữa trà xanh', 2, 'cafe_suatraxanh.jpg', 0),
(22, 'Café sữa vị trà', 2, 'cafe_suavitra.jpg', 0),
(23, 'Café tuyết', 2, 'cafe_tuyet.jpg', 0),
(24, 'Bánh kem hình dog', 3, 'banh_kemdog.jpg', 0),
(31, 'Bánh kem hình mèo', 3, 'banhkemmeo.jpg', 0),
(33, 'Như Thương', 1, 'banh_kemdog.jpg', 0),
(34, 'Như Thương', 1, 'banh_kemdog.jpg', 0),
(35, 'Sangsss', 3, 'banh_kemsocola.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `taikhoan`
--

CREATE TABLE `taikhoan` (
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `MatKhau` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `taikhoan`
--

INSERT INTO `taikhoan` (`Email`, `MatKhau`) VALUES
('nguyenkhang1400@gmail.com', '$2y$10$dgohpeD2KW8qsGqujEFYmOQNiXuTnQ7/Hz22oHyJgxoVUJX4EJGeq'),
('nhu8103@gmail.com', '$2y$10$ScXv/tRvgTs1yf2vrK8J1OkUauBHgFgQxRnkJzLJ1.MrC7YAQkKgO'),
('sangnguyen07dhth@gmail.com', '$2y$10$9r/LWdJt5zmd1.s2LY6z1OgXWbOffqtSF/zoQAGQ6CwxP9NJdDGd2'),
('sangnguyen07dhth@istore.edu.vn', '$2y$10$irsBmEYrrJikpkS6NawI4ep1Lg7sOmRO.r78z0AxVyhnVDmGHFWQ6'),
('sn5648562@gmail.com', '$2y$10$Qcf1k4pFr1ZqBvHZyssZN.h5Kq6MUPcO7PPg.e8cVl8jVrYSeWlIe');

-- --------------------------------------------------------

--
-- Table structure for table `theloaisp`
--

CREATE TABLE `theloaisp` (
  `ID_TLSP` int(11) NOT NULL,
  `TenTL` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `theloaisp`
--

INSERT INTO `theloaisp` (`ID_TLSP`, `TenTL`) VALUES
(1, 'Trà Sữa'),
(2, 'Cafe'),
(3, 'Bánh ngọt');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cthd`
--
ALTER TABLE `cthd`
  ADD PRIMARY KEY (`ID_CTHD`),
  ADD KEY `FK_CTHD_HOADON_IDHD` (`ID_HD`),
  ADD KEY `FK_CTHD_SP_IDSP` (`ID_SP`);

--
-- Indexes for table `donvitinh`
--
ALTER TABLE `donvitinh`
  ADD PRIMARY KEY (`ID_SP`,`Size`);

--
-- Indexes for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD PRIMARY KEY (`ID_HD`),
  ADD KEY `FK_HOADON_KH_IDKH` (`ID_KH`);

--
-- Indexes for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD PRIMARY KEY (`ID_KH`),
  ADD KEY `FK_KH_TK_EMAIL` (`EmailKH`);

--
-- Indexes for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD PRIMARY KEY (`ID_NV`),
  ADD KEY `FK_NV_TK_EMAIL` (`Email`);

--
-- Indexes for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`ID_SP`),
  ADD KEY `FK_SP_TLSP_IDTLSP` (`ID_TheLoaiSP`);

--
-- Indexes for table `taikhoan`
--
ALTER TABLE `taikhoan`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `theloaisp`
--
ALTER TABLE `theloaisp`
  ADD PRIMARY KEY (`ID_TLSP`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cthd`
--
ALTER TABLE `cthd`
  MODIFY `ID_CTHD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `hoadon`
--
ALTER TABLE `hoadon`
  MODIFY `ID_HD` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `khachhang`
--
ALTER TABLE `khachhang`
  MODIFY `ID_KH` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `nhanvien`
--
ALTER TABLE `nhanvien`
  MODIFY `ID_NV` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `ID_SP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `theloaisp`
--
ALTER TABLE `theloaisp`
  MODIFY `ID_TLSP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cthd`
--
ALTER TABLE `cthd`
  ADD CONSTRAINT `FK_CTHD_HOADON_IDHD` FOREIGN KEY (`ID_HD`) REFERENCES `hoadon` (`ID_HD`),
  ADD CONSTRAINT `FK_CTHD_SP_IDSP` FOREIGN KEY (`ID_SP`) REFERENCES `sanpham` (`ID_SP`);

--
-- Constraints for table `donvitinh`
--
ALTER TABLE `donvitinh`
  ADD CONSTRAINT `donvitinh_ibfk_1` FOREIGN KEY (`ID_SP`) REFERENCES `sanpham` (`ID_SP`);

--
-- Constraints for table `hoadon`
--
ALTER TABLE `hoadon`
  ADD CONSTRAINT `FK_HOADON_KH_IDKH` FOREIGN KEY (`ID_KH`) REFERENCES `khachhang` (`ID_KH`);

--
-- Constraints for table `khachhang`
--
ALTER TABLE `khachhang`
  ADD CONSTRAINT `FK_KH_TK_EMAIL` FOREIGN KEY (`EmailKH`) REFERENCES `taikhoan` (`Email`);

--
-- Constraints for table `nhanvien`
--
ALTER TABLE `nhanvien`
  ADD CONSTRAINT `FK_NV_TK_EMAIL` FOREIGN KEY (`Email`) REFERENCES `taikhoan` (`Email`);

--
-- Constraints for table `sanpham`
--
ALTER TABLE `sanpham`
  ADD CONSTRAINT `FK_SP_TLSP_IDTLSP` FOREIGN KEY (`ID_TheLoaiSP`) REFERENCES `theloaisp` (`ID_TLSP`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
