<?php
error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
//include('Models/database.php');
class User{
    public function register($email,$mk,$nhaplaimk,$hoten,$sodt,$dchi){
        $data=new database();
		
		$connect=$data->connect();
        
        $mk=password_hash($mk,PASSWORD_DEFAULT);
        
        $stmt1=$connect->prepare("INSERT INTO TaiKhoan SET Email=:email , MatKhau=:matkhau");
        
        $stmt1->bindParam(':email',$email);
        $stmt1->bindParam(':matkhau',$mk);
        
        $stmt1->execute();
        
        $stmt2=$connect->prepare("INSERT INTO KhachHang SET HoTenKH=:hoten,DiaChiKH=:diachi,SDT=:sdt,EmailKH=:emailkh");
        
        $stmt2->bindParam(':hoten',$hoten);
        $stmt2->bindParam(':diachi',$dchi);
        $stmt2->bindParam(':sdt',$sodt);
        $stmt2->bindParam(':emailkh',$email);
        
        $stmt2->execute();
        
        $data->disconnect($connect);
        
        
    }
    
    public function login($email,$matkhau){
        $data=new database();
		
		$connect=$data->connect();
        
        $stmt=$connect->prepare("SELECT * FROM TaiKhoan WHERE Email=:email");
        
        $stmt->bindParam(':email',$email);
        
        $stmt->execute();
        
        $result=$stmt->fetch(PDO::FETCH_ASSOC);
        
        $data->disconnect($connect);
        
        if($stmt->rowCount()==1){
            return $result;
        }
        return;
    }
    
    public function reset_password($email,$password){
        $data=new database();
		
		$connect=$data->connect();
        
        $stmt=$connect->prepare("UPDATE TaiKhoan SET MatKhau=:matkhau WHERE Email=:email");
        
        $stmt->bindParam(':matkhau',$password);
        $stmt->bindParam(':email',$email);
        
        $stmt->execute();
        
        $data->disconnect($connect);
    }
	/*public function login(){
		return 'login';	
	}
	public function add(){
		return 'add';	
	}
	public function edit(){
		return 'edit';	
	}
	public function del(){
		return 'del';	
	}
	public function listed(){
		return 'listed';	
	}*/
}
?>