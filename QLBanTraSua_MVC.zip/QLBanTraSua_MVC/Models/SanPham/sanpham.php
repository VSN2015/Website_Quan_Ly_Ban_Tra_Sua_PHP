<?php
	class SanPham{
		private $id;
		private $tenSP;
		private $anhSP;
		private $size;
		private $gia;
		
		public function __construct(){
		}
		public function __construct($id,$tensp,$anhsp,$size,$gia){
			$this->id=$id;
			$this->tenSP=$tensp;
			$this->anhSP=$anhsp;
			$this->size=$size;
			$this->gia= $gia;
		}
		
		
	} 
?>