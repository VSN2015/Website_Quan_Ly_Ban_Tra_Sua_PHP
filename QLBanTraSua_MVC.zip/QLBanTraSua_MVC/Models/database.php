<?php
class database{
	function connect(){
		try{
			$servername='localhost';

			$db_name='DB_QL_BanTraSua';

			$username='root';

			$password='';

			$connect=new PDO("mysql:host=$servername;dbname=$db_name;charset=utf8",$username,$password);

			$connect->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

			return $connect;
		}
		catch(PDOException $e){
			echo 'ERROR: '.$e->getMessage();
			}
		}
	
	function disconnect($conn){
		try{
			$conn=null;
		}
		catch(PDOException $e){
			echo 'ERROR: '.$e->getMessage();
			}
		}
}
?>