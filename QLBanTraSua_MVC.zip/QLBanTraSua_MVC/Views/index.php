<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="Library/fonts/font-awesome.min.css" type="text/css" rel="stylesheet"/>
    <link href="Library/css/style.css" type="text/css" rel="stylesheet"/>
    <script src="Library/jquery/jquery-1.11.1.min.js" type="text/javascript"></script>
    <script src="Library/bootstrap/bootstrap.min.js" type="text/javascript"></script>
</head>
<body>
    <div id="page">
        <header class="header-container">
            <!-- Navbar -->
            <nav>
                <div class="header container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Header Logo -->
                            <div class="col-md-2 col-lg-2 col-sm-8 col-xs-7 logo-header">
                                <a class="logo" href="index.html">
                                    <img alt="Coffee House" src="Library/images/logo.png"/>
                                </a>
                            </div>
                            <div class="nav-mobile hidden-lg hidden-md">
                                <div class="top-cart-contain" id="open_shopping_cart">
                                    <div class="mini-cart">
                                    <div class="basket dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">
                                         <a href="p/gio-hang.html"><i class="fa fa-shopping-cart"></i><span class="item_count"><span class="simpleCart_quantity"></span></span></a>
                                    </div>
                                    <ul class="mini-products-list" id="cart-sidebar">
                                        <div class="top-cart-content open_button arrow_box shopping_cart dropdown find" data-amount="0" style="display: none;"><ol class="cart-products-list" id="top-cart-sidebar"><div class="simpleCart_items"></div>
                                        </ol>
                                        <strong>Tổng giá tiền:</strong>
                                        <span class="price" id="jshop_summ_product">
                                        <span class="simpleCart_finalTotal"></span></span>
                                        <div class="animated_item actions"><a class=" view-cart" href="p/gio-hang.html">Giỏ hàng</a><a class=" btn-checkout" href="p/thanh-toan.html">Thanh toán</a></div>
                                        </div>
                                    </ul>
                                    </div>
                                </div>
                                <!-- Header Top Links -->
                                <div class="toplinks">
                                    <div class="links">
                                        <div class="login">
                                            <a href="#"></a>
<!--                                            <a href="login/login.html" title="Đăng nhập"><i class="fa fa-user"></i></a>-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Header Logo -->
                            <div class="col-md-10 col-lg-10 col-sm-12">
                                <div class="nav-inner">
                                <ul class="" id="nav">
                                    <li class="level0 parent drop-menu active">
                                        <a href="index.html"><span>Trang chủ</span></a>
                                    </li>
                                    <li class="level0 parent drop-menu ">
                                        <a href="gioi-thieu.html"><span>Giới thiệu</span></a>
                                    </li>
                                    <li class="level0 parent drop-menu ">
                                    <a href="collections/all.html"><span>Sản phẩm</span></a>
                                        <ul class="level1" style="display: none;">
                                            <li class="level1 first ">
                                                <a href="san-pham-noi-bat.html">
                                                    <span>Sản phẩm nổi bật</span>
                                                </a>
                                            </li>
                                            <li class="level1 first ">
                                                <a href="san-pham-khuyen-mai.html">
                                                    <span>Sản phẩm khuyến mại</span>
                                                </a>
                                            </li>
                                            <li class="level1 first ">
                                                <a href="frontpage.html">
                                                    <span>Sản phẩm mới</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="level0 parent drop-menu"><a href="tin-tuc.html"><span>Tin tức</span>
                                    </a>
                                    </li>
                                    <li class="level0 parent drop-menu"><a href="lien-he.html"><span>Liên hệ</span>
                                    </a>
                                    </li>
                                </ul>
                                </div>
                                <div class="nav-inner hidden-sm hidden-xs" style="z-index:0">
                                    <div class="top-cart-contain" >
                                        <div class="mini-cart">
                                            <div class="basket dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">
                                                <a href="p/gio-hang.html">
                                                <i class="fa fa-shopping-cart"></i> Giỏ hàng <span class="cart-total">(<span class="simpleCart_quantity"></span>)</span>
                                                </a>
                                            </div>
                                                <ul class="mini-products-list" id="cart-sidebar">
                                                    <div class="top-cart-content open_button arrow_box shopping_cart dropdown find" data-amount="0" style="display: none;">
                                                        <ol class="cart-products-list" id="top-cart-sidebar">
                                                            <div class="simpleCart_items"></div>
                                                        </ol>
                                                        <strong>Tổng giá tiền:</strong>
                                                        <span class="price" id="jshop_summ_product">
                                                        <span class="simpleCart_finalTotal"></span></span>
                                                        <div class="animated_item actions">
                                                            <a class=" view-cart" href="p/gio-hang.html">Giỏ hàng</a>
                                                            <a class=" btn-checkout" href="p/thanh-toan.html">Thanh toán</a>
                                                        </div>
                                                    </div>
                                                </ul>
                                        </div>
                                    </div>
                                    <!-- Header Top Links -->
                                    <?php if(!isset($_SESSION['user'])){ ?>
                                    <div class="toplinks">
                                        <div class="links">
                                            <div class="login">
                                                <a href="index.php?controller=user&&action=login" title="Đăng nhập"><span class="hidden-xs">Đăng nhập</span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php 
                                    }
                                    else{
                                    ?>
                                    <div class="toplinks">
                                        <div class="links">
                                            <div class="login">
                                                <a href="index.php?controller=user&&action=logout" title="Đăng xuất"><span class="hidden-xs">Đăng xuất(<?php echo $_SESSION['user'] ?>)</span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <?php 
                                    }
                                    ?>
                                    
                                    <div class="form_search">
                                        <form action="https://coffee-housetemplate.blogspot.com/search" class="navbar-form form_search_index" method="get">
                                            <div class="input-group">
                                                <input class="form-control block_in" id="search" maxlength="70" name="q" placeholder="Tìm kiếm" type="text" value=""/>
                                                <span class="input-group-btn">
                                                <button class="btn btn-default" type="submit" value="submit_search">
                                                <i class="fa fa-search"></i> Tìm kiếm</button>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
        <!-- end header -->
        <section class="bg_slide">
        <div id="slide">
        <div class="slider-wrap">
        <div class="carousel slide" data-ride="carousel" id="slide-item-carousel">
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
        <div class="item active">
        <a href="#"><img alt="..." src="Library/images/slide_2.jpg"/></a>
        </div>
        <div class="item">
        <a href="#"><img alt="..." src="Library/images/slide.jpg"/></a>
        </div>
        </div>
        <a class="left slide-item-carousel-control" data-slide="prev" href="#slide-item-carousel">
        <img src="Library/images/arrow-left.png"/>
        </a>
        <a class="right slide-item-carousel-control" data-slide="next" href="#slide-item-carousel">
        <img src="Library/images/arrow-right.png"/>
        </a>
        </div>
        </div>
        </div>
        </section>
        <section class="gallery_bg">
        <div class="container">
        <div class="row">
        <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="about-title">
        <h3>
        <img src="Library/images/typo.png"/>
        </h3>
        </div>
        <div class="about-content">
                            "Đi cà phê" từ lâu không đơn thuần chỉ là uống một tách cà phê mà còn là dịp gặp mặt và trò chuyện cùng bạn bè. Tại The Coffee House, chúng tôi trân trọng và đề cao giá trị kết nối giữa con người và trải nghiệm của khách hàng. Chúng tôi tin tưởng mạnh mẽ rằng thức uống với chất lượng tốt nhất được phục vụ trong không gian thân thiện bởi những nhân viên tận tâm tại The Coffee House sẽ mang lại những niềm vui bạn có thể chia sẻ cùng bạn bè và gia đình. The Coffee House luôn luôn chào đón bạn.
        </div>
        <div class="viewmore">
        <a href="gioi-thieu.html">Xem chi tiết</a>
        </div>
        </div>
        <div class="col-md-6 col-sm-6 hidden-sm hidden-xs col-xs-12">
        <div id="slide">
        <div class="slider-wrap">
        <div class="carousel slide" data-ride="carousel" id="carousel-example-generic">
        <!-- Indicators -->
        <ol class="carousel-indicators">
        <li class="active" data-slide-to="0" data-target="#carousel-example-generic"></li>
        <li data-slide-to="1" data-target="#carousel-example-generic"></li>
        <li data-slide-to="2" data-target="#carousel-example-generic"></li>
        </ol>
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
        <div class="item active">
        <a href="#"><img alt="" src="Library/images/bg_slide_2.png"/></a>
        </div>
        <div class="item">
        <a href="#"><img alt="" src="Library/images/bg_slide.png"/></a>
        </div>
        <div class="item">
        <a href="#"><img alt="" src="Library/images/bg_slide_3.png"/></a>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </div>
        </section>
        <!-- Mục sản phẩm 1-->
        <script type="text/javascript">
            $(document).ready(function() {

            $('#itemslider').carousel({
                interval: 3000
            });

            $('.carousel-showmanymoveone .item').each(function() {
                var itemToClone = $(this);

                for (var i = 1; i < 6; i++) {
                    itemToClone = itemToClone.next();

                    if (!itemToClone.length) {
                        itemToClone = $(this).siblings(':first');
                    }

                    itemToClone.children(':first-child').clone()
                        .addClass("cloneditem-" + (i))
                        .appendTo($(this));
                }
            });
        });
        </script>
        <section class="best-seller-pro">
        <div class="container">
        <div class="slider-items-products">
        <div class="new_title center">
        <h2>Đồ uống bán chạy</h2>
        </div>
        <div class="container-fluid">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="carousel carousel-showmanymoveone slide" id="itemslider">
                <div class="carousel-inner">

                  <div class="item active">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trachaudaxay.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAYORAL SUKNJA</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/tranchausuatuoi.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAYORAL KOŠULJA</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuakhoaimon.jpg" class="img-responsive center-block"></a>
                      <span class="badge">-10%</span>
                      <h4 class="text-center">PANTALONE TERI 2</h4>
                      <h5 class="text-center">400.000 VND</h5>
                      <h6 class="text-center">500.000 VND</h6>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuamatong.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">CVETNA HALJINA</h4>
                      <h5 class="text-center">600.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuatranchau.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAJICA FOTO</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuatranchauhokkido.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAJICA MAYORAL</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                </div>
                <!-- left,right control -->
                <div id="slider-control">
                <a class="left carousel-control" href="#itemslider" data-slide="prev"><img src="Library/images/arrow_left.png" alt="Left" class="img-responsive"></a>
                <a class="right carousel-control" href="#itemslider" data-slide="next"><img src="Library/images/arrow_right.png" alt="Right" class="img-responsive"></a>
              </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        </div>
        </section>
        <!--/ End Mục sản phẩm 1-->
        <!-- Mục sản phẩm 2-->
        <!--<script type="text/javascript">
            $(document).ready(function() {

            $('#itemslide').carousel({
                interval: 3000
            });

            $('.carousel-showmanymoveone .item').each(function() {
                var itemToClone = $(this);

                for (var i = 1; i < 6; i++) {
                    itemToClone = itemToClone.next();

                    if (!itemToClone.length) {
                        itemToClone = $(this).siblings(':first');
                    }

                    itemToClone.children(':first-child').clone()
                        .addClass("cloneditem-" + (i))
                        .appendTo($(this));
                }
            });
        });
        </script>-->
        <section class="best-seller-pro">
        <div class="container">
        <div class="slider-items-products">
        <div class="new_title center">
        <h2>Sản phẩm mới</h2>
        </div>
        <div class="container-fluid">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
              <div class="carousel carousel-showmanymoveone slide" id="itemslider">
                <div class="carousel-inner">

                  <div class="item active">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trachaudaxay.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAYORAL SUKNJA</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/tranchausuatuoi.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAYORAL KOŠULJA</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuakhoaimon.jpg" class="img-responsive center-block"></a>
                      <span class="badge">-10%</span>
                      <h4 class="text-center">PANTALONE TERI 2</h4>
                      <h5 class="text-center">400.000 VND</h5>
                      <h6 class="text-center">500.000 VND</h6>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuamatong.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">CVETNA HALJINA</h4>
                      <h5 class="text-center">600.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuatranchau.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAJICA FOTO</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                  <div class="item">
                    <div class="col-xs-12 col-sm-6 col-md-2">
                      <a href="#"><img src="Library/images/img_sanphamts/trasuatranchauhokkido.jpg" class="img-responsive center-block"></a>
                      <h4 class="text-center">MAJICA MAYORAL</h4>
                      <h5 class="text-center">400.000 VND</h5>
                    </div>
                  </div>

                </div>
                <!-- left,right control -->
                <div id="slider-control">
                <a class="left carousel-control" href="#itemslider" data-slide="prev"><img src="Library/images/arrow_left.png" alt="Left" class="img-responsive"></a>
                <a class="right carousel-control" href="#itemslider" data-slide="next"><img src="Library/images/arrow_right.png" alt="Right" class="img-responsive"></a>
              </div>
              </div>
            </div>
          </div>
        </div>
        </div>
        </div>
        </section>
        <!--/ End Mục sản phẩm 2-->
        <section class="banner_home">
        <div class="container">
        <div class="row">
        <div class="col-md-4 col-sm-4 hidden-xs banner-home">
        <figcaption>
        <a href="#"><img src="Library/images/banner1.png"/></a>
        </figcaption>
        </div>
        <div class="col-md-8 col-sm-8 hidden-xs banner-home">
        <figcaption>
        <a href="#"><img src="Library/images/banner2.png"/></a>
        </figcaption>
        </div>
        </div>
        </div>
        </section>
        <!--footer-->
        <footer class="footer hidden-xs">
        <div class="footer-middle">
        <div class="container">
        <div class="row">
        <!--tin tức-->
        <div class="col-md-6 col-sm-6 col-xs-12">
        <div class="blog-footer ">
        <div class="blog_title">
        <h3>Tin tức</h3>
        <a href="tin-tuc.html">Xem tất cả <i class="fa fa-angle-double-right"></i></a>
        </div>
        <!--<script language="JavaScript"> //<![CDATA[
        document.write("<script src=\"/feeds/posts/default/-/Tin tức?max-results="+2+"&orderby=published&alt=json-in-script&callback=showrecentposts1\"><\/script>");      //]]>
        </script>-->
        </div>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 categories-footer">
        <div class="blog_title">
        <h3>Danh mục sản phẩm</h3>
        </div>
        <ul class="links">
        <li><a href="#LINK"><i class="fa fa-stop"></i> Trà sữa Thái Lan</a></li>
        <li><a href="#LINK"><i class="fa fa-stop"></i> Mocktail hoa quả</a></li>
        <li><a href="#LINK"><i class="fa fa-stop"></i> Sữa chưa uống</a></li>
        <li><a href="#LINK"><i class="fa fa-stop"></i> Trà trái cây</a></li>
        <li><a href="index.html#LINK"><i class="fa fa-stop"></i> Nước trái cây</a></li>
        <li><a href="#LINK"><i class="fa fa-stop"></i> Chè ngũ vị</a></li>
        <li><a href="#LINK"><i class="fa fa-stop"></i> Coffee mộc</a></li>
        <li><a href="#LINK"><i class="fa fa-stop"></i> Coffee sữa chua</a></li>
        <li><a href="#LINK"><i class="fa fa-stop"></i> Coffee hoa quả</a></li>
        </ul>
        </div>
        <div class="col-md-3 col-sm-3 col-xs-12 contact-footer">
        <ul class="links-contact">
        <li>TRÀ SỮA SÀI GÒN</li>
        <li>Address: 140 Lê Trọng Tấn,P.Tây Thạnh,Q.Tân Phú,TP.HCM</li>
        <li>Phone:0969068625</li>
        <li>Email:sangnguyen07dhth@gmail.com</li>
        <li>Open time: 7h00 AM - 10h00 PM</li>
        <li>
        <a href="#"><i class="fa fa-facebook-official"></i></a>
        <a href="#"><i class="fa fa-youtube-square"></i></a>
        <a href="#"><i class="fa fa-users"></i></a>
        <a href="#"><i class="fa fa-comments"></i></a>
        </li>
        </ul>
        </div>
        </div>
        </div>
        </div>
        </footer>
<!--end footer-->
    </div>
</body>
</html>