<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password</title>
    <!-- Meta tag Keywords -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="Library/fonts/font-awesome.min.css" type="text/css" rel="stylesheet"/>
    <link href="Library/css/style.css" type="text/css" rel="stylesheet"/>
    <script src="Library/jquery/jquery-1.11.1.min.js" type="text/javascript"></script>
    <script src="Library/bootstrap/bootstrap.min.js" type="text/javascript"></script>
    <link rel="stylesheet" href="Library/css/font-awesome.css"> <!-- Font-Awesome-Icons-CSS -->
    <link rel="stylesheet" href="Library/css/style_login.css" type="text/css" media="all" /> <!-- Style-CSS --> 
    <!-- //css files -->
    <!-- web-fonts -->
    <link href="//fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700" rel="stylesheet">
    <link href="//fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700" rel="stylesheet">
    <link href="Library/css/style_loading.css" type="text/css" rel="stylesheet"/><!-- css loading-->
<!-- //web-fonts -->
</head>
<script type="text/javascript">// của hiệu ứng loading
    $(window).on('load', function(event) {
        $('body').removeClass('preloading');
        $('.load').delay(1000).fadeOut('fast');
    });
</script>
<body class="preloading">
    <div class="load" align="center">
        <img src="Library/images/loader.gif">
    </div>
    <!--header---------------------------------------------------->
    <div id="page">
        <header class="header-container">
            <!-- Navbar -->
            <nav>
                <div class="header container">
                    <div class="row">
                        <div class="col-xs-12">
                            <!-- Header Logo -->
                            <div class="col-md-2 col-lg-2 col-sm-8 col-xs-7 logo-header">
                                <a class="logo" href="../index.html">
                                    <img alt="Coffee House" src="Library/images/logo.png"/>
                                </a>
                            </div>
                            <div class="nav-mobile hidden-lg hidden-md">
                                <div class="top-cart-contain" id="open_shopping_cart">
                                    <div class="mini-cart">
                                    <div class="basket dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">
                                         <a href="p/gio-hang.html"><i class="fa fa-shopping-cart"></i><span class="item_count"><span class="simpleCart_quantity"></span></span></a>
                                    </div>
                                    <ul class="mini-products-list" id="cart-sidebar">
                                        <div class="top-cart-content open_button arrow_box shopping_cart dropdown find" data-amount="0" style="display: none;"><ol class="cart-products-list" id="top-cart-sidebar"><div class="simpleCart_items"></div>
                                        </ol>
                                        <strong>Tổng giá tiền:</strong>
                                        <span class="price" id="jshop_summ_product">
                                        <span class="simpleCart_finalTotal"></span></span>
                                        <div class="animated_item actions"><a class=" view-cart" href="p/gio-hang.html">Giỏ hàng</a><a class=" btn-checkout" href="p/thanh-toan.html">Thanh toán</a></div>
                                        </div>
                                    </ul>
                                    </div>
                                </div>
                                <!-- Header Top Links -->
                                <div class="toplinks">
                                    <div class="links">
                                        <div class="login">
                                            <a href="login/login.html"></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Header Logo -->
                            <div class="col-md-10 col-lg-10 col-sm-12">
                                <div class="nav-inner">
                                <ul class="" id="nav">
                                    <li class="level0 parent drop-menu active">
                                        <a href="index.html"><span>Trang chủ</span></a>
                                    </li>
                                    <li class="level0 parent drop-menu ">
                                        <a href="gioi-thieu.html"><span>Giới thiệu</span></a>
                                    </li>
                                    <li class="level0 parent drop-menu ">
                                    <a href="collections/all.html"><span>Sản phẩm</span></a>
                                        <ul class="level1" style="display: none;">
                                            <li class="level1 first ">
                                                <a href="san-pham-noi-bat.html">
                                                    <span>Sản phẩm nổi bật</span>
                                                </a>
                                            </li>
                                            <li class="level1 first ">
                                                <a href="san-pham-khuyen-mai.html">
                                                    <span>Sản phẩm khuyến mại</span>
                                                </a>
                                            </li>
                                            <li class="level1 first ">
                                                <a href="frontpage.html">
                                                    <span>Sản phẩm mới</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="level0 parent drop-menu"><a href="tin-tuc.html"><span>Tin tức</span>
                                    </a>
                                    </li>
                                    <li class="level0 parent drop-menu"><a href="lien-he.html"><span>Liên hệ</span>
                                    </a>
                                    </li>
                                </ul>
                                </div>
                                <div class="nav-inner hidden-sm hidden-xs" style="z-index:0">
                                    <div class="top-cart-contain" >
                                        <div class="mini-cart">
                                            <div class="basket dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">
                                                <a href="p/gio-hang.html">
                                                <i class="fa fa-shopping-cart"></i> Giỏ hàng <span class="cart-total">(<span class="simpleCart_quantity"></span>)</span>
                                                </a>
                                            </div>
                                                <ul class="mini-products-list" id="cart-sidebar">
                                                    <div class="top-cart-content open_button arrow_box shopping_cart dropdown find" data-amount="0" style="display: none;">
                                                        <ol class="cart-products-list" id="top-cart-sidebar">
                                                            <div class="simpleCart_items"></div>
                                                        </ol>
                                                        <strong>Tổng giá tiền:</strong>
                                                        <span class="price" id="jshop_summ_product">
                                                        <span class="simpleCart_finalTotal"></span></span>
                                                        <div class="animated_item actions">
                                                            <a class=" view-cart" href="p/gio-hang.html">Giỏ hàng</a>
                                                            <a class=" btn-checkout" href="p/thanh-toan.html">Thanh toán</a>
                                                        </div>
                                                    </div>
                                                </ul>
                                        </div>
                                    </div>
                                    <!-- Header Top Links -->
                                    <div class="toplinks">
                                        <div class="links">
                                            <div class="login">
                                                <a href="login/login.html" title="Đăng nhập"><span class="hidden-xs">Đăng nhập</span></a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form_search">
                                        <form action="https://coffee-housetemplate.blogspot.com/search" class="navbar-form form_search_index" method="get">
                                            <div class="input-group">
                                                <input class="form-control block_in" id="search" maxlength="70" name="q" placeholder="Tìm kiếm" type="text" value=""/>
                                                <span class="input-group-btn">
                                                <button class="btn btn-default" type="submit">
                                                <i class="fa fa-search"></i> Tìm kiếm</button>
                                                </span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </header>
    </div>
    <!------------------------------------------------------------>
		<div class="header-w3l">
             <div class="boxmenu">
                <form action="www.google.com">
                    <h1>Reset Mật Khẩu </h1>
                </form>
            </div>
		</div>
		<!--//header-->
		<!--main-->
		<div class="main-w3layouts-agileinfo">
	           <!--form-starts-here-->
						<div class="wthree-form">
							<!-- h2>Fill out the form below to login</h2>-->
							<form action="#" method="post">
                                <span class="invalid-feedback"><h4><p style="color: red"><?php echo $thongbao; ?></p></h4>
                                <span class="invalid-feedback"><p style="color: red"><?php echo($errors['email_err']); ?></p></span>
								<div class="form-sub-w3">
									<input type="email" name="Username" placeholder="Email" required="" />
								<div class="icon-w3">
									<i class="fa fa-user" aria-hidden="true"></i>
								</div>
								</div>
								<label class="anim">
                                    <a href="index.php?controller=user&action=login">Trở lại Đăng Nhập</a>
								</label> 
								<div class="clear"></div>
								<div class="submit-agileits">
									<input type="submit" name="forget_pass" value="Gửi link reset">
								</div>
							</form>

						</div>
				<!--//form-ends-here-->

		</div>
		<!--//main-->
		<!--footer-->
		<div class="footer">
			<p>Design by Văn Sang Nguyễn</p>
		</div>
		<!--//footer-->
</body>
</html>