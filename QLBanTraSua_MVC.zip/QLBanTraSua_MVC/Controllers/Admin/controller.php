<?php
    if(isset($_GET['action'])){
        switch($_GET['action']){
            case "trangchu": include("Controllers/Admin/TrangChu.php");
            break;
            case "sanpham": include("Controllers/Admin/SanPham.php");
            break;
        }
    }
?>