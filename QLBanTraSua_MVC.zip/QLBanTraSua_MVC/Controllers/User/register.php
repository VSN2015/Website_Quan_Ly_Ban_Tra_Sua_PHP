
<?php
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    if(!empty(isset($_POST['register']))){
        include('Models/funtions.php');
        $error= array();//tạo 1 mảng chứa các error
        
        $email=filter_input(INPUT_POST, 'txtEmail', FILTER_SANITIZE_EMAIL);
        $matkhau = filter_input(INPUT_POST, 'Password', FILTER_SANITIZE_STRING);
        $nhaplaimk=filter_input(INPUT_POST, 'NhapLaiPassword', FILTER_SANITIZE_STRING);
        $hoten=filter_input(INPUT_POST, 'txtHoTen', FILTER_SANITIZE_STRING);
        $sdt=filter_input(INPUT_POST, 'txtSDT', FILTER_SANITIZE_STRING);
        $diachi=filter_input(INPUT_POST, 'txtDiaChi', FILTER_SANITIZE_STRING);
        
        //ktra email----------------------------------------------------------------------------------
        $reg_email = '/^[a-z0-9]+@[a-z0-9]+(.com|.net|.org|.me)$/i'; 
        if(!preg_match($reg_email, $email)){
            $errors['email_err'] = 'Email không đúng chuẩn!!!';
            }
        elseif(checkUserByEmail($email)!=0){
             $errors['email_err'] = 'Email đã tồn tại !!!';
            }

        //ktra mật khẩu--------------------------------------------------------------------------------
        if(strlen($matkhau)>20 || strlen($matkhau)<5){
         $errors['matkhau_err'] = 'Mật khẩu phải >= 5 và <= 20 kí tự';
         }

         //ktra error nhập lại mk----------------------------------------------------------------------
         if($matkhau!=$nhaplaimk || empty($nhaplaimk)){
             $errors['nhaplaimk_err'] = 'Nhập lại mật khẩu không đúng hoặc trống';
         }

        // ktra họ và tên------------------------------------------------------------------------------
        if(strlen($hoten)>50 || strlen($hoten)<6){
         $errors['hoten_err'] = 'Họ và tên phải >=6 và <=50 kí tự';
        }

        //ktra sđt-------------------------------------------------------------------------------------
        if(strlen($sdt)!=10||empty($sdt)){
            $errors['sdt_err'] = 'Số điện thoại không đúng hoặc trống ';
        }

        if(empty($diachi)){
            $errors['diachi_err'] = 'Địa chỉ trống ';
        }
        if(count($errors)==0){
            include('Models/User/user.php');
            
            $u=new User();
                
            $u->register($email,$matkhau,$nhaplaimk,$hoten,$sdt,$diachi);
            
            $thongbao="Thông tin tài khoản đăng ký thành công :))";
            
            $message = "Bạn đã đăng ký thành công tài khoản trong trang web Sài Gòn Trà Sữa của chúng tôi";
            send_mail([
                
                'to' => $email,
                'message' => $message,
                'subject' => 'Thông tin tài khoản Trà Sữa SG',
                'from' => 'Trà Sữa Sài Gòn',
                
            ]);
            
        }
        else{
            $thongbao="Vui lòng nhập đầy đủ thông tin nhé :))";
        }

    }
    include('Views/User/register.php');



?>