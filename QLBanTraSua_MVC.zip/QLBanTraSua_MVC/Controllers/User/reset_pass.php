<?php
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    include('Models/funtions.php');
    if(!empty(isset($_POST['reset_pass']))){
        $error= array();//tạo 1 mảng chứa các error
        
        $matkhau = filter_input(INPUT_POST, 'txtPass', FILTER_SANITIZE_STRING);
        $nhaplaimk=filter_input(INPUT_POST, 'txtnhaplaiPassword', FILTER_SANITIZE_STRING);
        
        //ktra error mật khẩu--------------------------------------------------------------------------
        if(strlen($matkhau)>20 || strlen($matkhau)<5){
         $errors['matkhau_err'] = 'Mật khẩu phải >= 5 và <= 20 kí tự';
         }

         //ktra error nhập lại mk----------------------------------------------------------------------
         if($matkhau!=$nhaplaimk || empty($nhaplaimk)){
             $errors['nhaplaimk_err'] = 'Nhập lại mật khẩu không đúng hoặc trống';
         }
        
        if(count($errors)==0){
            include('Models/User/user.php');
            
            $u=new User();
            
            if(isset($_SESSION['user_reset'])){
                $email=$_SESSION['user_reset'];
                unset($_SESSION['user_reset']);
            }
                
            
            $matkhau = password_hash($matkhau, PASSWORD_DEFAULT);//băm mật khẩu 
            
            $u->reset_password($email,$matkhau);// update csdl
            
            $thongbao="Bạn đã reset mật khẩu thành công :). Vui lòng quay trở lại đăng nhập hi";
        }
        else
            $thongbao="Vui lòng nhập chính xác thông tin nhé !!!";
        
    }
    include('Views/User/reset_password.php');
?>