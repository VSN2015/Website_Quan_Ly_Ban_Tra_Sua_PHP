<?php
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    if(!empty(isset($_POST['login']))){
        include('Models/funtions.php');
        $error= array();//tạo 1 mảng chứa các error
        
        $email=filter_input(INPUT_POST, 'Username', FILTER_SANITIZE_EMAIL);
        $matkhau = filter_input(INPUT_POST, 'Password', FILTER_SANITIZE_STRING);
        $remember = isset($_POST['remember-me']) ? 'Yes' : '';
        
        //ktra email----------------------------------------------------------------------------------
        $reg_email = '/^[a-z0-9]+@[a-z0-9]+(.com|.net|.org|.me)$/i'; 
        if(!preg_match($reg_email, $email)){
            $errors['email_err'] = 'Email không đúng chuẩn!!!';
            }
        elseif(checkUserByEmail($email)==0){
             $errors['email_err'] = 'Email không tồn tại !!!';
            }

        //ktra mật khẩu--------------------------------------------------------------------------------
        if(strlen($matkhau)>20 || strlen($matkhau)<5){
         $errors['matkhau_err'] = 'Mật khẩu phải >= 5 và <= 20 kí tự';
         }
        if(count($errors)==0){
            include('Models/User/user.php');
            
            $u=new User();
            
            $result=$u->login($email,$matkhau);
            
            if(password_verify($matkhau,$result['MatKhau'])){
                if($remember=='Yes'){
                    setcookie('user', $email, time() + 3600, '/', '', 0, 0);
                    setcookie('pass', $matkhau, time() + 3600, '/', '', 0, 0);
                        
                }
                $_SESSION['user']=$email;
                if(isAdminLoggedIn($email)){
                     header("location:index.php?controller=admin&action=trangchu");
                    exit();
                }
                header("location:index.php?controller=home");
                    
                exit();
            }
            else{
                $thongbao="Email hoặc mật khẩu không đúng !!!";
            }
                
        }
        
        
    }

    include('Views/User/login.php');
?>