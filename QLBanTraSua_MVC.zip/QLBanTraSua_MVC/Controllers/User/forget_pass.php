<?php
    error_reporting(E_ALL & ~E_NOTICE & ~E_DEPRECATED);
    if(!empty(isset($_POST['forget_pass']))){
        include('Models/funtions.php');
        $error= array();//tạo 1 mảng chứa các error
        
        $email=filter_input(INPUT_POST, 'Username', FILTER_SANITIZE_EMAIL);
              
        //ktra email----------------------------------------------------------------------------------
        $reg_email = '/^[a-z0-9]+@[a-z0-9]+(.com|.net|.org|.me)$/i'; 
        if(!preg_match($reg_email, $email)){
            $errors['email_err'] = 'Email không đúng chuẩn!!!';
        }
        elseif(checkUserByEmail($email)==0){
             $errors['email_err'] = 'Email không tồn tại !!!';
        }
        
        if(count($errors)==0){
            $_SESSION['user_reset']=$email;// giữ lại email khách mún reset mk để qua bên reset pass xử lý
            
            $thongbao="Bạn đã yêu cầu reset lại mật khẩu thành công. Vui lòng kiểm tra email của bạn để reset!!!";
            
            $message="Bạn đã yêu cầu reset lại mật khẩu ! Vui lòng nhấp <a href='localhost:81/QLBanTraSua_MVC/index.php?controller=user&&action=reset_pass'>vào đây để reset lại mật khẩu</a>";
            send_mail([
                
                'to' => $email,
                'message' => $message,
                'subject' => 'Thông tin tài khoản Trà Sữa SG',
                'from' => 'Trà sữa Sài Gòn',
                
            ]);   
        }
        else
            $thongbao="Vui lòng nhập chính xác thông tin nhé !!!";
    }
    include "Views/User/forget_pass.php";
?>