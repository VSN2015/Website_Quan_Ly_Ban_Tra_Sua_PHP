<?php
    if(isset($_GET['action'])){
        switch($_GET['action']){
            case "login": include("Controllers/User/login.php");
            break;
            case "register": include("Controllers/User/register.php");
            break;
            case "forget_pass": include("Controllers/User/forget_pass.php");
            break;
            case "reset_pass" : include("Controllers/User/reset_pass.php");
            break;
            case "logout": include("Controllers/User/logout.php");
            break;
        }
    }
?>