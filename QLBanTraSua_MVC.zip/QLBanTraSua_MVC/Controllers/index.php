<?php
    include('Models/funtions.php');
    include('Views/index.php');
?>